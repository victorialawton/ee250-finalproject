//
//  ContentView.swift
//  DogFacts
//
//  Created by Sriya Kuruppath on 4/24/24.
//

import SwiftUI
import FirebaseDatabase
// Model to capture the common top-level response structure
struct ApiResponse<T: Codable>: Codable {
    let data: [T]
}

// Model for the attributes of a fact
struct FactAttributes: Codable {
    let body: String
    var liked: Bool? // true for liked, false for disliked, nil for no preference
}

struct BreedAttributes: Codable {
    let name: String
    let description: String
    let life: LifeSpan
    let male_weight: WeightRange
    let female_weight: WeightRange
    let hypoallergenic: Bool
    var liked: Bool?
}

struct GroupAttributes: Codable {
    let name: String
    var liked: Bool?
}


// Life span, weight range for breeds
struct LifeSpan: Codable {
    let max: Int
    let min: Int
}

struct WeightRange: Codable {
    let max: Int
    let min: Int
}

// Generic model for any entity with attributes
struct GenericEntity<Attributes: Codable>: Codable {
    let id: String
    let type: String
    var attributes: Attributes
}
struct SummaryView: View {
    @ObservedObject var fetcher: DogFactFetcher

    var body: some View {
        VStack {
            Text("Summary of Preferences").font(.title)
            List {
                Text("Favorite Facts").bold()
                ForEach(fetcher.facts.filter { $0.attributes.liked == true }, id: \.id) { fact in
                    Text(fact.attributes.body)
                }
                
                Text("Least Favorite Breeds").bold()
                ForEach(fetcher.breeds.filter { $0.attributes.liked == false }, id: \.id) { breed in
                    Text(breed.attributes.name)
                }
                
                Text("Favorite Groups").bold()
                ForEach(fetcher.groups.filter { $0.attributes.liked == true }, id: \.id) { group in
                    Text(group.attributes.name)
                }
            }
        }
    }
}

// Fetch functions adjusted for each type
class DogFactFetcher: ObservableObject {
    @Published var facts: [GenericEntity<FactAttributes>] = []
    @Published var breeds: [GenericEntity<BreedAttributes>] = []
    @Published var groups: [GenericEntity<GroupAttributes>] = []

    private let baseURL = "https://dogapi.dog/api/v2"

    // Generic fetch method
    private func fetch<T: Codable>(endpoint: String, completion: @escaping ([T]) -> Void) {
        let urlString = "\(baseURL)/\(endpoint)"
        guard let url = URL(string: urlString) else {
            print("Invalid URL")
            return
        }

        URLSession.shared.dataTask(with: url) { data, _, error in
            guard let data = data, error == nil else {
                print("Failed to fetch data: \(error?.localizedDescription ?? "Unknown error")")
                return
            }

            do {
                let response = try JSONDecoder().decode(ApiResponse<T>.self, from: data)
                DispatchQueue.main.async {
                    completion(response.data)
                }
            } catch {
                print("Decoding failed: \(error)")
            }
        }.resume()
    }

    // Specific fetch functions
    func fetchFacts() {
        fetch(endpoint: "facts") { (fetchedFacts: [GenericEntity<FactAttributes>]) in
            self.facts = fetchedFacts
        }
    }

    func fetchBreeds() {
        fetch(endpoint: "breeds") { (fetchedBreeds: [GenericEntity<BreedAttributes>]) in
            self.breeds = fetchedBreeds
        }
    }

    func fetchGroups() {
        fetch(endpoint: "groups") { (fetchedGroups: [GenericEntity<GroupAttributes>]) in
            self.groups = fetchedGroups
        }
    }
}


struct ContentView: View {
    @ObservedObject var fetcher = DogFactFetcher()
    @State private var updateID = UUID()

    var body: some View {
        NavigationView {
            List {
                Section(header: Text("Facts")) {
                    ForEach(fetcher.facts, id: \.id) { fact in
                        VStack {
                            Text(fact.attributes.body)
                            HStack {
                                Button(action: {
                                    print("Like button tapped for fact id: \(fact.id)")
                                    updateFactPreference(factId: fact.id, liked: true)
                                }) {
                                    Text("Like")
                                        .foregroundColor(.white)
                                        .padding()
                                        .background(Color.green)
                                        .cornerRadius(10)
                                }
                                .buttonStyle(PlainButtonStyle())

                                Button(action: {
                                    print("Dislike button tapped for fact id: \(fact.id)")
                                    updateFactPreference(factId: fact.id, liked: true)
                                }) {
                                    Text("Dislike")
                                        .foregroundColor(.white)
                                        .padding()
                                        .background(Color.red)
                                        .cornerRadius(10)
                                }
                                .buttonStyle(PlainButtonStyle())
                                
                            }
                        }
                    }
                }
                Section(header: Text("Breeds")) {
                    ForEach(fetcher.breeds, id: \.id) { breed in
                        VStack(alignment: .leading) {
                            Text(breed.attributes.name).fontWeight(.bold)
                            Text(breed.attributes.description).font(.caption)
                            Text("Life span: \(breed.attributes.life.min)-\(breed.attributes.life.max) years").font(.caption)
                            HStack {
                                Button(action: {
                                    updateBreedPreference(breedId: breed.id, liked: true)
                                }) {
                                    Text("Like")
                                        .foregroundColor(.white)
                                        .padding()
                                        .background(Color.green)
                                        .cornerRadius(10)
                                }
                                .buttonStyle(PlainButtonStyle())
                                Button(action: {
                                    updateBreedPreference(breedId: breed.id, liked: false)
                                }) {
                                    Text("Dislike")
                                        .foregroundColor(.white)
                                        .padding()
                                        .background(Color.red)
                                        .cornerRadius(10)
                                }
                                .buttonStyle(PlainButtonStyle())
                            }
                        }
                    }
                }
                Section(header: Text("Groups")) {
                    ForEach(fetcher.groups, id: \.id) { group in
                        VStack {
                            Text(group.attributes.name).fontWeight(.bold)
                            HStack {
                                Button(action: {
                                    updateGroupPreference(groupId: group.id, liked: true)
                                }) {
                                    Text("Like")
                                        .foregroundColor(.white)
                                        .padding()
                                        .background(Color.green)
                                        .cornerRadius(10)
                                }
                                .buttonStyle(PlainButtonStyle())
                                Button(action: {
                                    updateGroupPreference(groupId: group.id, liked: false)
                                }) {
                                    Text("Dislike")
                                        .foregroundColor(.white)
                                        .padding()
                                        .background(Color.red)
                                        .cornerRadius(10)
                                }
                                .buttonStyle(PlainButtonStyle())
                            }
                        }
                    }
                }
            }
            .id(updateID) // Use an ID to force the view to redraw
            .navigationTitle("Dog API")
            .onAppear {
                fetcher.fetchFacts()
                fetcher.fetchBreeds()
                fetcher.fetchGroups()
            }
        }
        
    }
    func refreshView() {
            updateID = UUID() // Changes the ID, causing SwiftUI to redraw the view
        }
    

    func updateFactPreference(factId: String, liked: Bool) {
        guard let index = fetcher.facts.firstIndex(where: { $0.id == factId }) else { return }
        // Notify views about the upcoming change
        fetcher.objectWillChange.send()
        fetcher.facts[index].attributes.liked = liked
    }

    func updateBreedPreference(breedId: String, liked: Bool) {
        guard let index = fetcher.breeds.firstIndex(where: { $0.id == breedId }) else { return }
        // Notify views about the upcoming change
        fetcher.objectWillChange.send()
        fetcher.breeds[index].attributes.liked = liked
    }

    func updateGroupPreference(groupId: String, liked: Bool) {
        guard let index = fetcher.groups.firstIndex(where: { $0.id == groupId }) else { return }
        // Notify views about the upcoming change
        fetcher.objectWillChange.send()
        fetcher.groups[index].attributes.liked = liked
    }

}



#Preview {
    ContentView()
}
