//
//  ContentView.swift
//  DogFacts
//
//  Created by Sriya Kuruppath on 4/24/24.
//

import SwiftUI
// Model to capture the common top-level response structure
struct ApiResponse<T: Codable>: Codable {
    let data: [T]
}

// Model for the attributes of a fact
struct FactAttributes: Codable {
    let body: String
}

// Model for the attributes of a breed
struct BreedAttributes: Codable {
    let name: String
    let description: String
    let life: LifeSpan
    let male_weight: WeightRange
    let female_weight: WeightRange
    let hypoallergenic: Bool
}

// Model for the attributes of a group
struct GroupAttributes: Codable {
    let name: String
}

// Life span, weight range for breeds
struct LifeSpan: Codable {
    let max: Int
    let min: Int
}

struct WeightRange: Codable {
    let max: Int
    let min: Int
}

// Generic model for any entity with attributes
struct GenericEntity<Attributes: Codable>: Codable {
    let id: String
    let type: String
    let attributes: Attributes
}

// Fetch functions adjusted for each type
class DogFactFetcher: ObservableObject {
    @Published var facts: [GenericEntity<FactAttributes>] = []
    @Published var breeds: [GenericEntity<BreedAttributes>] = []
    @Published var groups: [GenericEntity<GroupAttributes>] = []

    private let baseURL = "https://dogapi.dog/api/v2"

    // Generic fetch method
    private func fetch<T: Codable>(endpoint: String, completion: @escaping ([T]) -> Void) {
        let urlString = "\(baseURL)/\(endpoint)"
        guard let url = URL(string: urlString) else {
            print("Invalid URL")
            return
        }

        URLSession.shared.dataTask(with: url) { data, _, error in
            guard let data = data, error == nil else {
                print("Failed to fetch data: \(error?.localizedDescription ?? "Unknown error")")
                return
            }

            do {
                let response = try JSONDecoder().decode(ApiResponse<T>.self, from: data)
                DispatchQueue.main.async {
                    completion(response.data)
                }
            } catch {
                print("Decoding failed: \(error)")
            }
        }.resume()
    }

    // Specific fetch functions
    func fetchFacts() {
        fetch(endpoint: "facts") { (fetchedFacts: [GenericEntity<FactAttributes>]) in
            self.facts = fetchedFacts
        }
    }

    func fetchBreeds() {
        fetch(endpoint: "breeds") { (fetchedBreeds: [GenericEntity<BreedAttributes>]) in
            self.breeds = fetchedBreeds
        }
    }

    func fetchGroups() {
        fetch(endpoint: "groups") { (fetchedGroups: [GenericEntity<GroupAttributes>]) in
            self.groups = fetchedGroups
        }
    }
}


struct ContentView: View {
    @ObservedObject var fetcher = DogFactFetcher()
    
    var body: some View {
        NavigationView {
            List {
                Section(header: Text("Facts")) {
                    ForEach(fetcher.facts, id: \.id) { fact in
                        Text(fact.attributes.body)
                    }
                }
                Section(header: Text("Breeds")) {
                    ForEach(fetcher.breeds, id: \.id) { breed in
                        VStack(alignment: .leading) {
                            Text(breed.attributes.name).fontWeight(.bold)
                            Text(breed.attributes.description).font(.caption)
                            Text("Life span: \(breed.attributes.life.min)-\(breed.attributes.life.max) years").font(.caption)
                        }
                    }
                }
                Section(header: Text("Groups")) {
                    ForEach(fetcher.groups, id: \.id) { group in
                        Text(group.attributes.name).fontWeight(.bold)
                    }
                }
            }
            .navigationTitle("Dog API")
            .onAppear {
                fetcher.fetchFacts()
                fetcher.fetchBreeds()
                fetcher.fetchGroups()
            }
        }
    }
}


#Preview {
    ContentView()
}
