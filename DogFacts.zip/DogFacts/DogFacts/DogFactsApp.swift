//
//  DogFactsApp.swift
//  DogFacts
//
//  Created by Sriya Kuruppath on 4/24/24.
//

import SwiftUI
import FirebaseCore
@main
struct DogFactsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
